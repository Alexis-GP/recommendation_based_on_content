import json
import sqlite3
import pandas as pd
from datetime import datetime

def create_monthly_tag_database():
    """
    将monthly_tag_frequencies.json中的数据导入到SQLite数据库，并从users.csv添加username
    创建的表结构：
    - monthly_tags(id, month, user_id, username, tag, frequency)
    """
    # 连接到SQLite数据库
    conn = sqlite3.connect('tags.db')
    cursor = conn.cursor()
    
    # 创建表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS monthly_tags (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        month TEXT NOT NULL,
        user_id TEXT NOT NULL,
        username TEXT,
        tag TEXT NOT NULL,
        frequency INTEGER NOT NULL,
        UNIQUE(month, user_id, tag)
    )
    ''')
    
    # 读取JSON文件和users.csv文件
    try:
        with open('monthly_tag_frequencies.json', 'r', encoding='utf-8') as f:
            monthly_data = json.load(f)
        
        # 读取users.csv获取用户名信息
        users_df = pd.read_csv('users.csv')
        # 创建user_id到username的映射
        user_map = dict(zip(users_df['uid'].astype(str), users_df['username']))
        
    except FileNotFoundError as e:
        print(f"Error: {e}")
        return
    
    # 准备批量插入的数据
    insert_data = []
    
    # 遍历JSON数据
    for month in monthly_data:
        for user_id, tags in monthly_data[month].items():
            # 获取用户名，如果在映射中不存在则保持用户ID
            username = user_map.get(user_id, user_id)
            # 如果username是NaN，使用user_id
            if pd.isna(username):
                username = user_id
                
            for tag, freq in tags.items():
                insert_data.append((month, user_id, username, tag, freq))
    
    # 批量插入数据
    try:
        cursor.executemany(
            '''INSERT OR REPLACE INTO monthly_tags 
               (month, user_id, username, tag, frequency) 
               VALUES (?, ?, ?, ?, ?)''',
            insert_data
        )
        conn.commit()
        
        # 打印统计信息
        cursor.execute('SELECT COUNT(DISTINCT month) FROM monthly_tags')
        month_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT user_id) FROM monthly_tags')
        user_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT tag) FROM monthly_tags')
        tag_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM monthly_tags')
        total_records = cursor.fetchone()[0]
        
        print(f"数据导入成功！")
        print(f"总月份数: {month_count}")
        print(f"总用户数: {user_count}")
        print(f"总标签数: {tag_count}")
        print(f"总记录数: {total_records}")
        
        # 打印一些有用户名的示例
        cursor.execute('''
            SELECT month, username, tag, frequency 
            FROM monthly_tags 
            WHERE username != user_id 
            LIMIT 5
        ''')
        print("\n用户名映射示例:")
        for row in cursor.fetchall():
            print(f"{row[0]} - {row[1]}: {row[2]} ({row[3]}次)")
        
    except sqlite3.Error as e:
        print(f"数据库错误: {e}")
        conn.rollback()
    
    finally:
        conn.close()

def query_examples():
    """
    查询示例
    """
    conn = sqlite3.connect('tags.db')
    cursor = conn.cursor()
    
    # 1. 查询某个月份最常用的标签及其使用者数量
    def get_top_tags_by_month(month, limit=10):
        cursor.execute('''
            SELECT tag, 
                   SUM(frequency) as total_freq,
                   COUNT(DISTINCT user_id) as user_count,
                   GROUP_CONCAT(DISTINCT username) as users
            FROM monthly_tags
            WHERE month = ?
            GROUP BY tag
            ORDER BY total_freq DESC
            LIMIT ?
        ''', (month, limit))
        return cursor.fetchall()
    
    # 2. 查询某个用户的标签使用历史
    def get_user_tags(username, start_month, end_month):
        cursor.execute('''
            SELECT month, username, tag, frequency
            FROM monthly_tags
            WHERE username = ? AND month BETWEEN ? AND ?
            ORDER BY month, frequency DESC
        ''', (username, start_month, end_month))
        return cursor.fetchall()
    
    # 3. 查询使用某个标签最多的用户
    def get_top_users_by_tag(tag, limit=10):
        cursor.execute('''
            SELECT username, user_id, SUM(frequency) as total_freq
            FROM monthly_tags
            WHERE tag = ?
            GROUP BY user_id
            ORDER BY total_freq DESC
            LIMIT ?
        ''', (tag, limit))
        return cursor.fetchall()
    
    # 示例查询
    print("\n2020年1月最常用的标签及其主要使用者:")
    for tag, freq, user_count, users in get_top_tags_by_month('2020-01'):
        print(f"{tag}: 使用{freq}次，{user_count}个用户使用")
        print(f"主要使用者: {users[:100]}...")  # 只显示部分用户名
    
    print("\n查询'笔吧评测室'2020年上半年的标签使用情况:")
    for month, username, tag, freq in get_user_tags('笔吧评测室', '2020-01', '2020-06'):
        print(f"{month}: {tag} ({freq}次)")
    
    print("\n使用'科技'标签最多的用户:")
    for username, user_id, freq in get_top_users_by_tag('科技'):
        print(f"{username}(ID:{user_id}): {freq}次")
    
    conn.close()

if __name__ == "__main__":
    create_monthly_tag_database()
    query_examples()




