import json
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from matplotlib import font_manager
import matplotlib
from collections import Counter
import pandas as pd
from collections import defaultdict
from datetime import datetime
import numpy as np
from PIL import Image
import sqlite3

def set_chinese_font():
    """设置中文字体"""
    try:
        font_path = font_manager.findfont('PingFang HK', fallback_to_default=False)
        return font_path
    except:
        print("警告：未找到苹方字体，图形可能无法正确显示中文")
        return None

def create_tag_wordcloud(mask_image_path=None, start_date=None, end_date=None):
    """
    生成标签词云图
    Args:
        mask_image_path: 可选，背景蒙版图片路径，需要是白底黑色轮廓的图片
        start_date: 可选，起始日期，格式为 'YYYY-MM'
        end_date: 可选，结束日期，格式为 'YYYY-MM'
    """
    # 连接到SQLite数据库
    conn = sqlite3.connect('tags.db')
    cursor = conn.cursor()
    
    # 初始化标签频次计数器
    tag_frequencies = Counter()
    
    try:
        if start_date or end_date:
            # 从数据库中读取指定时间范围的数据
            query = '''
                SELECT tag, SUM(frequency) as total_freq
                FROM monthly_tags
                WHERE 1=1
            '''
            params = []
            
            if start_date:
                query += ' AND month >= ?'
                params.append(start_date)
            if end_date:
                query += ' AND month <= ?'
                params.append(end_date)
                
            query += ' GROUP BY tag'
            
            cursor.execute(query, params)
            
            # 获取查询结果并存入Counter
            for tag, freq in cursor.fetchall():
                tag_frequencies[tag] = freq
            
            print(f"统计时间范围: {start_date if start_date else '开始'} 至 {end_date if end_date else '结束'}")
            
        else:
            # 读取所有时间的数据
            cursor.execute('''
                SELECT tag, SUM(frequency) as total_freq
                FROM monthly_tags
                GROUP BY tag
            ''')
            
            # 获取查询结果并存入Counter
            for tag, freq in cursor.fetchall():
                tag_frequencies[tag] = freq
    
    except sqlite3.Error as e:
        print(f"数据库错误: {e}")
        return
    
    finally:
        conn.close()
    
    # 获取中文字体路径
    font_path = set_chinese_font()
    
    # 创建粉蓝色系的颜色函数
    def color_func(word, font_size, position, orientation, random_state=None, **kwargs):
        # 使用随机数来决定颜色，确保粉色和蓝色的概率各为50%
        if np.random.random() < 0.5:
            # 粉色系：基准色相330，允许±10的随机变化
            hue = 330 + np.random.randint(-10, 10)
            return f"hsl({hue}, 75%, {np.random.randint(60, 75)}%)"  # 粉色系列
        else:
            # 蓝色系：基准色相210，允许±10的随机变化
            hue = 210 + np.random.randint(-10, 10)
            return f"hsl({hue}, 75%, {np.random.randint(60, 75)}%)"  # 蓝色系列
    
    # 创建词云对象的基本参数
    wordcloud_params = {
        'font_path': font_path,      
        'width': 3200,               
        'height': 2700,              
        'background_color': 'white',
        'max_words': 5000,           
        'max_font_size': 300,        
        'min_font_size': 1,          
        'prefer_horizontal': 1,       
        'random_state': 42,
        'color_func': color_func     # 添加自定义颜色函数
    }
    
    # 如果提供了蒙版图片，则读取并添加到参数中
    if mask_image_path:
        # 读取图片
        mask = np.array(Image.open(mask_image_path))
        # 如果是彩色图片，转换为灰度图
        if len(mask.shape) > 2:
            mask = mask.mean(axis=2)
        wordcloud_params['mask'] = mask
    
    # 创建词云对象
    wordcloud = WordCloud(**wordcloud_params)
    
    # 生成词云
    wordcloud.generate_from_frequencies(tag_frequencies)
    
    # 创建图形
    plt.figure(figsize=(64, 54), facecolor='white')  # 调整图形大小以匹配词云尺寸
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    
    # 保存图片
    time_suffix = f"_{start_date}_to_{end_date}" if start_date and end_date else ""
    output_filename = f'bilibili_word{time_suffix}.png' if mask_image_path else f'tag_wordcloud{time_suffix}.png'
    
    plt.savefig(output_filename,
                dpi=400,              # 增加DPI到600
                bbox_inches='tight',
                pad_inches=0,         # 移除边距
                facecolor='white',
                edgecolor='none')
    plt.close()
    
    # 打印一些统计信息
    print(f"总标签数量: {len(tag_frequencies)}")
    print("\n使用频次最高的10个标签:")
    for tag, freq in sorted(tag_frequencies.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"{tag}: {freq}次")

def create_monthly_tag_frequencies():
    """按月份统计标签使用频次"""
    # 读取CSV文件
    df = pd.read_csv('videos.csv')
    
    # 初始化数据结构
    monthly_tag_freq = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    
    # 遍历每一行数据
    for _, row in df.iterrows():
        # 跳过标签为空的行
        if pd.isna(row['labels']):
            continue
            
        # 获取时间戳并转换为年月
        try:
            timestamp = int(row['timestamp_upload'])
            date = datetime.fromtimestamp(timestamp)
            month_key = f"{date.year}-{date.month:02d}"
        except (ValueError, TypeError):
            continue
            
        # 处理标签
        tags = [tag.strip() for tag in row['labels'].split(',')]
        uid = str(row['uid'])
        
        # 统计每个用户在该月份的标签使用频次
        for tag in tags:
            monthly_tag_freq[month_key][uid][tag] += 1
    
    # 将defaultdict转换为普通dict以便JSON序列化
    result = {
        month: {
            uid: dict(user_tags)
            for uid, user_tags in month_data.items()
        }
        for month, month_data in monthly_tag_freq.items()
    }
    
    # 保存到JSON文件
    with open('monthly_tag_frequencies.json', 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    # 打印一些统计信息
    print(f"总月份数: {len(result)}")
    print("\n按月份统计的数据示例:")
    for month in sorted(list(result.keys()))[:5]:  # 显示前5个月份
        total_tags = sum(
            len(tags) for user_tags in result[month].values()
            for tags in [user_tags.keys()]
        )
        print(f"{month}: {len(result[month])}个用户, {total_tags}个标签")

def batch_create_tag_wordcloud(mask_image_path=None, start_year=2010, end_year=2024):
    """
    批量生成标签词云图
    Args:
        mask_image_path: 可选，背景蒙版图片路径
        start_year: 起始年份
        end_year: 结束年份
    """
    for year in range(start_year, end_year + 1):
        start_date = f"{year}-01"
        end_date = f"{year}-12"
        print(f"生成 {year} 年的词云图...")
        create_tag_wordcloud(mask_image_path, start_date, end_date)

if __name__ == "__main__":
    batch_create_tag_wordcloud('bilibili.png', 2016, 2024)
    # create_monthly_tag_frequencies()
