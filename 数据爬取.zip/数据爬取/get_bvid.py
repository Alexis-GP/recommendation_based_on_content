import os
import os.path as osp
import json
import time
import random
import re
import datetime
import warnings
import sys
from selenium import webdriver
from bs4 import BeautifulSoup
import argparse
import errno

def mkdir_if_missing(dirname):
    """Creates dirname if it is missing."""
    if not osp.exists(dirname):
        try:
            os.makedirs(dirname)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise

def write_json(obj, fpath):
    """Writes to a json file."""
    mkdir_if_missing(osp.dirname(fpath))
    with open(fpath, 'w', encoding='utf-8') as f:
        json.dump(obj, f, indent=4, separators=(',', ': '), ensure_ascii=False)  # 添加中文支持

def read_json(fpath):
    """Reads json file from a path."""
    with open(fpath, 'r') as f:
        obj = json.load(f)
    return obj

class Bilibili_Spider():
    def __init__(self, uid, save_dir_json='json', save_by_page=False, t=2):
        self.t = t
        self.uid = uid
        self.user_url = 'https://space.bilibili.com/{}'.format(uid)
        self.save_dir_json = save_dir_json
        self.save_by_page = save_by_page
        options = webdriver.FirefoxOptions()
        options.add_argument('--headless')
        self.browser = webdriver.Firefox(options=options)
        print('Spider initialized for UID: {}'.format(uid))

    def close(self):
        """Close the browser driver."""
        self.browser.quit()

    def date_convert(self, date_str):
        """Convert date string to a standard format."""
        if '小时前' in date_str:
            hours = int(re.search(r'(\d+)小时前', date_str).group(1))
            pub_datetime = datetime.datetime.now() - datetime.timedelta(hours=hours)
            return pub_datetime.strftime('%Y-%m-%d')
        elif '昨天' in date_str:
            pub_datetime = datetime.datetime.now() - datetime.timedelta(days=1)
            return pub_datetime.strftime('%Y-%m-%d')
        else:
            date_item = date_str.split('-')
            if len(date_item) == 2:
                year = datetime.datetime.now().strftime('%Y')
                return '{}-{:>02d}-{:>02d}'.format(year, int(date_item[0]), int(date_item[1]))
            else:
                return '{}-{:>02d}-{:>02d}'.format(date_item[0], int(date_item[1]), int(date_item[2]))

    def get_page_num(self):
        """Get the total number of pages for the user's videos."""
        page_url = self.user_url + '/video?tid=0&pn=1&keyword=&order=pubdate'
        self.browser.get(page_url)
        time.sleep(self.t + 2 * random.random())
        html = BeautifulSoup(self.browser.page_source, features="html.parser")
        
        # Debug: Print the HTML content to check if the page is loaded correctly
        # print(html.prettify())

        page_number_element = html.find('span', attrs={'class': 'be-pager-total'})
        if page_number_element is None:
            raise ValueError("Could not find the page number element. The page structure might have changed.")
        
        page_number = page_number_element.text
        user_name_element = html.find('span', id='h-name')
        if user_name_element is None:
            raise ValueError("Could not find the user name element. The page structure might have changed.")
        
        user_name = user_name_element.text
        print('Total pages: {}, User Name: {}'.format(page_number, user_name))
        return int(page_number.split(' ')[1]), user_name

    def get_videos_by_page(self, idx):
        """Get video information from a specific page."""
        urls_page, titles_page, plays_page, dates_page, durations_page = [], [], [], [], []
        page_url = self.user_url + '/video?tid=0&pn={}&keyword=&order=pubdate'.format(idx + 1)
        self.browser.get(page_url)
        time.sleep(self.t + 2 * random.random())
        html = BeautifulSoup(self.browser.page_source, features="html.parser")
        ul_data = html.find('div', id='submit-video-list').find('ul', attrs={'class': 'clearfix cube-list'})

        for li in ul_data.find_all('li'):
            a = li.find('a', attrs={'target': '_blank', 'class': 'title'})
            a_url = 'https:{}'.format(a['href'])
            a_title = a.text
            date_str = li.find('span', attrs={'class': 'time'}).text.strip()
            pub_date = self.date_convert(date_str)
            now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            play = li.find('span', attrs={'class': 'play'}).text.strip()
            time_str = li.find('span', attrs={'class': 'length'}).text
            urls_page.append(a_url)
            titles_page.append(a_title)
            dates_page.append((pub_date, now))
            plays_page.append(play)
            durations_page.append(time_str)

        return urls_page, titles_page, plays_page, dates_page, durations_page

    def save(self, json_path, bvs, urls, titles, plays, durations, dates):
        """Save video information to a JSON file."""
        data_list = []
        for i in range(len(urls)):
            result = {
                'user_name': self.user_name,
                'bv': bvs[i],
                'url': urls[i],
                'title': titles[i],
                'play': plays[i],
                'duration': durations[i],
                'pub_date': dates[i][0],
                'now': dates[i][1]
            }
            data_list.append(result)

        print('Writing JSON to {}'.format(json_path))
        mkdir_if_missing(osp.dirname(json_path))
        write_json(data_list, json_path)
        print('Dumped JSON file done. Total {} URLs.'.format(len(urls)))

    def get(self):
        """Get all video information for the user."""
        print('Starting to fetch video information...')
        self.page_num, self.user_name = self.get_page_num()
        while self.page_num == 0:
            print('Failed to get user page num, retrying...')
            self.page_num, self.user_name = self.get_page_num()

        bvs, urls, titles, plays, dates, durations = [], [], [], [], [], []

        for idx in range(self.page_num):
            print('Fetching page {}/{}'.format(idx + 1, self.page_num))
            urls_page, titles_page, plays_page, dates_page, durations_page = self.get_videos_by_page(idx)
            while len(urls_page) == 0:
                print('Failed to fetch page {}/{}'.format(idx + 1, self.page_num))
                urls_page, titles_page, plays_page, dates_page, durations_page = self.get_videos_by_page(idx)

            bvs_page = [x.split('/')[-2] for x in urls_page]
            bvs.extend(bvs_page)
            urls.extend(urls_page)
            titles.extend(titles_page)
            plays.extend(plays_page)
            dates.extend(dates_page)
            durations.extend(durations_page)

        # Save all video information to JSON
        json_path = osp.join(self.save_dir_json, f'videos_info_{self.uid}.json')
        self.save(json_path, bvs, urls, titles, plays, durations, dates)

def main(args):
    bilibili_spider = Bilibili_Spider(args.uid, args.save_dir, args.save_by_page, args.time)
    bilibili_spider.get()
    if args.detailed:
        bilibili_spider.get_detail()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--uid', type=str, default='362548791')
    parser.add_argument('--save_dir', type=str, default='json')
    parser.add_argument('--save_by_page', action='store_true', default=False)
    parser.add_argument('--time', type=int, default=2, help='waiting time for browser.get(url) by seconds')
    parser.add_argument('--detailed', action='store_true', default=False)
    args = parser.parse_args()
    print(args)
    
    main(args)
