import requests
import json
from get_data_from_db import split_bvid as bvid
import sqlite3
from bs4 import BeautifulSoup
import re

def download_video_labels(bvid: str):
    """Download and print video labels for a given BVID."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': f'https://www.bilibili.com/video/{bvid}/?p=1',
        'Origin': 'https://www.bilibili.com',
        'Connection': 'keep-alive',
        'Cookie': "buvid3=1F3F8087-761A-EC94-C010-FA288D019B9C38260infoc; b_nut=1714035538; _uuid=1881063E9-C7AE-510510-3AFA-62396E8D9161041788infoc; buvid4=0A4F598F-3856-1F11-A702-13112BA30B9F42694-024042508-F5Nx4SbwUx%2FD%2BBclYSrKRw%3D%3D; rpdid=|(u~J~mmJkRR0J'u~uR|JllRJ; header_theme_version=CLOSE; enable_web_push=DISABLE; SESSDATA=195cc5e7%2C1744218386%2C77dbe%2Aa2CjDHBcmM8NsGCR_6jxU6pPJqSe_dDUdj3TRi4p7YyZnpXV9P2RHU7rk2RLEZkQKu79ESVjk0c1hPLVpVeFlXLXNmRXlRc0NlemZBd0JPaDNIOVJUV18tUzhWV0JyLTU4eVFNeG5LQU1YbTVBWm1wVFJ6TDFoYS1yU3o2WW03TVlidjFRUDExM1pnIIEC; bili_jct=50994d5b7fe7f9d69f33e88c63518ed3; DedeUserID=3461568392071967; DedeUserID__ckMd5=51715bd0eda8f7c8; home_feed_column=5; browser_resolution=1512-823; fingerprint=abc34a2fceacc2408071067414337a4b; buvid_fp_plain=undefined; is-2022-channel=1; buvid_fp=abc34a2fceacc2408071067414337a4b; CURRENT_FNVAL=4048; match_float_version=ENABLE; bili_ticket=eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MzI4NzM5NjMsImlhdCI6MTczMjYxNDcwMywicGx0IjotMX0.ItnygZ6CLU-yH78jxHD_C0ja_2KgmnPUpEKfLXCJUcE; bili_ticket_expires=1732873903; bsource=search_google; sid=8l3sdt7l; bp_t_offset_3461568392071967=1004073902520926208; b_lsid=55D3813C_1936CD5CA74",  # 请替换为你的 Cookie
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-site',
    }

    try:
        # 获取视频的aid
        resp = requests.get(f'https://www.bilibili.com/video/{bvid}/', headers=headers)
        resp.raise_for_status()
        text = resp.text
        aid = text[text.find('"aid"') + 6:]
        aid = aid[:aid.find(',')]

        # 获取视频标签
        label_resp = requests.get(f'https://api.bilibili.com/x/tag/archive/tags?aid={aid}', headers=headers)
        label_resp.raise_for_status()

        labels_data = label_resp.json()
        if 'data' in labels_data:
            labels = [tag['tag_name'] for tag in labels_data['data']]
            print(f"视频 {bvid} 的标签: {labels}")
            return labels
        else:
            print(f"视频 {bvid} 没有标签信息")
            return []

    except requests.exceptions.RequestException as e:
        print(f"请求过程中发生错误: {e}")
        return []
    except KeyError as e:
        print(f"KeyError: {e} - 无法找到 {bvid} 的标签信息")
        return []
    except Exception as e:
        print(f"处理 {bvid} 时发生其他错误: {e}")
        return []

def save_labels_to_db(bvid, labels):
    """Save video labels to the database."""
    if not labels:
        print(f"No labels to save for {bvid}.")
        return

    # 连接到 SQLite 数据库
    conn = sqlite3.connect('bilibili_network.db')
    cursor = conn.cursor()

    # 将标签列表转换为字符串
    labels_str = ', '.join(labels)

    # 插入或更新数据
    cursor.execute('''
        INSERT INTO videos (bvid, labels) VALUES (?, ?)
        ON CONFLICT(bvid) DO UPDATE SET labels=excluded.labels
    ''', (bvid, labels_str))

    # 提交事务并关闭连接
    conn.commit()
    conn.close()

def get_video_stats(bvid: str):
    """获取视频统计信息"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': f'https://www.bilibili.com/video/{bvid}/?p=1',
        'Origin': 'https://www.bilibili.com',
        'Connection': 'keep-alive',
    }

    try:
        # 获取视频页面
        url = f'https://www.bilibili.com/video/{bvid}/'
        resp = requests.get(url, headers=headers)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")

        # 提取视频统计信息
        initial_state_script = soup.find("script", string=re.compile("window.__INITIAL_STATE__"))
        initial_state_text = initial_state_script.string

        # 使用正则表达式提取统计信息
        views_pattern = re.compile(r'"view":(\d+)')
        danmaku_pattern = re.compile(r'"danmaku":(\d+)')
        likes_pattern = re.compile(r'"like":(\d+)')
        coins_pattern = re.compile(r'"coin":(\d+)')
        favorites_pattern = re.compile(r'"favorite":(\d+)')
        shares_pattern = re.compile(r'"share":(\d+)')
        reply_pattern = re.compile(r'"reply":(\d+)')  # 新增评论数的正则表达式
        dislike_pattern = re.compile(r'"dislike":(\d+)')  # 新增不喜欢数的正则表达式

        views = views_pattern.search(initial_state_text).group(1)
        danmaku = danmaku_pattern.search(initial_state_text)
        likes = likes_pattern.search(initial_state_text).group(1)
        coins = coins_pattern.search(initial_state_text).group(1)
        favorites = favorites_pattern.search(initial_state_text).group(1)
        shares = shares_pattern.search(initial_state_text).group(1)
        reply = reply_pattern.search(initial_state_text).group(1)  # 提取评论数
        dislike = dislike_pattern.search(initial_state_text).group(1)  # 提取不喜欢数

        # 如果未找到 danmaku，设置默认值
        danmaku_value = int(danmaku.group(1)) if danmaku else 0

        print(f"视频 {bvid} 的统计信息: 播放量: {views}, 弹幕数: {danmaku_value}, 点赞数: {likes}, 投币数: {coins}, 收藏人数: {favorites}, 转发人数: {shares}, 评论数: {reply}, 不喜欢数: {dislike}")
        
        stats = {
            "views": int(views),
            "danmaku": danmaku_value,
            "likes": int(likes),
            "coins": int(coins),
            "favorites": int(favorites),
            "shares": int(shares),
            "reply": int(reply),  # 添加评论数
            "dislike": int(dislike)  # 添加不喜欢数
        }
        return stats

    except requests.exceptions.HTTPError as e:
        print(f"请求过程中发生错误: {e}")
        return {}
    except Exception as e:
        print(f"处理 {bvid} 时发生其他错误: {e}")
        return {}

def save_stats_to_db(bvid, stats):
    """Save video statistics to the database."""
    if not stats:
        print(f"No statistics to save for {bvid}.")
        return

    # 连接到 SQLite 数据库
    conn = sqlite3.connect('bilibili_network.db')
    cursor = conn.cursor()

    # 插入或更新数据
    cursor.execute('''
        INSERT INTO videos (bvid, danmuku, favourite, coin, share, like, reply, dislike) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(bvid) DO UPDATE SET 
            danmuku=excluded.danmuku,
            favourite=excluded.favourite,
            coin=excluded.coin,
            share=excluded.share,
            like=excluded.like,
            reply=excluded.reply,
            dislike=excluded.dislike
    ''', (bvid, stats['danmaku'], stats['favorites'], stats['coins'], stats['shares'], stats['likes'], stats['reply'], stats['dislike']))

    # 提交事务并关闭连接
    conn.commit()
    conn.close()

# download_video_labels('BV1134y1B7hh')


conn = sqlite3.connect('bilibili_network.db')
cursor = conn.cursor()

cursor.execute('''
    SELECT bvid FROM videos where like is null
''')
bvid_list = cursor.fetchall()
bvid_list = [bvid[0] for bvid in bvid_list]
print(len(bvid_list))

# for bvid in bvid_list:
#     stats = get_video_stats(bvid)
#     save_stats_to_db(bvid, stats)
#     print(bvid + ' done' + '\n')

