import sqlite3
import time
from datetime import datetime

def fetch_data_from_db(db_path, query):
    # Connect to the SQLite database
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()
    
    # Execute the provided query
    cursor.execute(query)
    
    # Fetch all results and convert them to a list of strings
    data = [row[0] for row in cursor.fetchall()]
    
    # Close the cursor and connection
    cursor.close()
    connection.close()
    
    return data

def split_list(original_list, chunk_size):
    num_chunks = (len(original_list) + chunk_size - 1) // chunk_size
    split_lists = {}
    for i in range(num_chunks):
        start = i * chunk_size
        end = min((i + 1) * chunk_size, len(original_list))
        split_lists[f'bvid_{i + 1}'] = original_list[start:end]
    return split_lists

db_path = 'bilibili_network.db'
query = "SELECT bvid FROM videos"

#  Fetch data using the query
bvids = fetch_data_from_db(db_path, query)

# Print the fetched data
# print(len(bvids))

chunk_size = 1330

split_bvid = split_list(bvids , chunk_size)

# print(len(split_bvid.get('bvid_40')))


# print(split_bvid.get('bvid_40'))

# print(split_bvid.get('bvid_6'))



